import { Component, OnInit } from '@angular/core';
import { analyzeAndValidateNgModules } from '@angular/compiler';


@Component({
  selector: 'app-home',
  template: `
 
    <section class="hero is-info is-fullheight is-bold">
    <div class="hero-body">
    <div class="container">
                <div class="row">
                       <div class="column">
                              <h1 class="txt">
                                     <p> 11+ \n </p>
                                    <p>PREPARATON \n </p>
                                     <p>CLASSES </p>
                              
                              </h1>
                      </div>
                      <div class="column">
                        <img class="img" src="assets/img/1.jpg"  style="width:100%;height:100%">
                      </div>
            
              </div>
                    
                                      <!-- Slideshow container -->
                        <div class="slideshow-container">

                          <!-- Full-width images with number and caption text -->
                          <div class="mySlides fade">
                            <div alt="firstSlide" class="numbertext">1 / 3</div>
                            <img src="assets/img/1.jpg" style="width:100%;">
                                                    <div class="content">
                                                      <div class="Imgcolumn">
                                                          <h1 class="txtSubHeader">Class Timings for Year 5 on Saturday:</h1>
                                                                <p>09:30 – 10:30 - English, Creative Writing or VR\n </p>
                                                                <p>10:30 – 11:30 - Maths or NVR \n </p>
                                                                <p>11:30 – 12:00 - Assessment</p>
                                                      
                                                            
                                                        </div>
                                                        <div class="Imgcolumn">
                                                            <h1 class="txtSubHeader">Class Timings for Year 5 on Thursday:</h1>
                                                            <p>06:45 – 07:45 PM - English, Creative Writing or VR\n </p>
                                                            <p>07:45 – 08:45 PM - Maths or NVR\n </p>
                                                           
                                                      
                                                      
                                                        </div>
                                                       </div>

                                                      <div class="content1">
                                                            <div class="Imgcolumn1">
                                                            <h1 class="txtSubHeader">Class Timings for Year 4 on Saturday:</h1>
                                                                      <p>09:30 – 10:30 - English, Creative Writing or VR\n </p>
                                                                      <p>10:30 – 11:30 - Maths or NVR\n </p>
                                                                      
                                                            
                                                                  
                                                            </div>
                                                            <div class="Imgcolumn1">
                                                              <h1 class="txtSubHeader">Class Timings for Year 4 on Tuesday:</h1>
                                                                      <p>06:45 – 07:45 PM - English, Creative Writing or VR\n </p>
                                                                      <p>07:45 – 08:45 PM - Maths or NVR\n </p>
                                                                      
                                                                
                                                               
                                                            </div>
                                                      </div>
                                                
                            
                          </div>

                          <div class="mySlides fade">
                            <div class="numbertext">2 / 3</div>
                            <img src="assets/img/2.jpg" style="width:100%;">
                            <div class="text">Caption Two</div>
                          </div>

                          <div class="mySlides fade">
                            <div class="numbertext">3 / 3</div>
                            <img src="assets/img/1.jpg" style="width:100%;">
                            <div class="text">Caption Three</div>
                          </div>

                          <!-- Next and previous buttons -->
                          <a class="prev" onclick="plusSlides(-1)">&#10094;</a>
                          <a class="next" onclick="plusSlides(1)">&#10095;</a>
                        </div>
                        <br>

                        <!-- The dots/circles -->
                        <div style="text-align:center">
                          <span class="dot" onclick="currentSlide(1)"></span>
                          <span class="dot" onclick="currentSlide(2)"></span>
                          <span class="dot" onclick="currentSlide(3)"></span>
                        </div>
            







          

    </div>
    </div>
    </section>
  `,
  styles: [`
  
  .content {
    position: absolute; /* Position the background text */
    top: 0; /* At the bottom. Use top:0 to append it to the top */
    height: 50%;
    background: rgb(0, 0, 0); /* Fallback color */
    background: rgba(0, 0, 0, 0.5); /* Black background with 0.5 opacity */
    color: #f1f1f1; /* Grey text */
    width: 100%; /* Full width */
    padding: 0px; /* Some padding */

  }
  .content1 {
    position: absolute; /* Position the background text */
    bottom: 0; /* At the bottom. Use top:0 to append it to the top */
    height: 50%;
    background: rgb(0, 0, 0); /* Fallback color */
    background: rgba(0, 0, 0, 0.5); /* Black background with 0.5 opacity */
    color: #f1f1f1; /* Grey text */
    width: 100%; /* Full width */
    padding: 0px; /* Some padding */

  }
.Imgcolumn{
  float: left;
  width: 50%;
  border-style: solid;
  border-color: DarkWhite;
  height:100%;

}
.Imgcolumn1{
  float: left;
  width: 50%;
  border-style: solid;
  border-color: DarkWhite;
  height:100%;
 
}
  * {box-sizing:border-box}

/* Slideshow container */
.slideshow-container {
  max-width: 1000px;
  position: relative;
  margin: auto;
  
}

/* Hide the images by default */
.mySlides {
  display: none;
}

/* Next & previous buttons */
.prev, .next {
  cursor: pointer;
  position: absolute;
  top: 50%;
  width: auto;
  margin-top: -22px;
  padding: 16px;
  color: white;
  font-weight: bold;
  font-size: 18px;
  transition: 0.6s ease;
  border-radius: 0 3px 3px 0;
  user-select: none;
}

/* Position the "next button" to the right */
.next {
  right: 0;
  border-radius: 3px 0 0 3px;
}

/* On hover, add a black background color with a little bit see-through */
.prev:hover, .next:hover {
  background-color: rgba(0,0,0,0.8);
}

/* Caption text */
.text {
  color: #f2f2f2;
  font-size: 15px;
  padding: 8px 12px;
  position: absolute;
  bottom: 8px;
  width: 100%;
  text-align: center;
}
.txtSubHeader{
  font-size: 30px;
}
/* Number text (1/3 etc) */
.numbertext {
  color: #f2f2f2;
  font-size: 12px;
  padding: 8px 12px;
  position: absolute;
  top: 0;
}

/* The dots/bullets/indicators */
.dot {
  cursor: pointer;
  height: 15px;
  width: 15px;
  margin: 0 2px;
  background-color: #bbb;
  border-radius: 50%;
  display: inline-block;
  transition: background-color 0.6s ease;
}

.active, .dot:hover {
  background-color: #717171;
}

/* Fading animation */
.fade {
  -webkit-animation-name: fade;
  -webkit-animation-duration: 1.5s;
  animation-name: fade;
  animation-duration: 1.5s;
}

@-webkit-keyframes fade {
  from {opacity: .4}
  to {opacity: 1}
}

@keyframes fade {
  from {opacity: .4}
  to {opacity: 1}
}

  /* Three image containers (use 25% for four, and 50% for two, etc) */
.column {
  border-style: solid;
  border-color: DarkWhite;
  background-color: #292929;
  float: left;
  width: 50%; 
  height: 350px;
  position: relative;
 
  
  
}
.img {
 
  height: 340px;
  padding: 10px;
 }
 h1 {
  text-align: center;
  text-transform: uppercase;
  color: white;
  padding: 10px;
  font-size: 50px;
  font-family: "Times New Roman", Times, serif;
}
p{
  margin: 5px;
  padding: 5px;
}
/* Clear floats after image containers */
.row::after {
  height: 50px;
  content: "";
  clear: both;
  display: table;
}
.firstSlide{
  background-image: url('/assets/img/canyon.jpg') !important;

}
    .hero {
      background-image: url('/assets/img/canyon.jpg') !important;
      background-size: cover;
      background-position: center center;
    }
  `]
})
export class HomeComponent implements OnInit {
  constructor() {}

  ngOnInit() {var slideIndex = 0;
    showSlides();
    
    function showSlides() {
      var i;
      var slides = Array.from(document.getElementsByClassName("mySlides")as HTMLCollectionOf<HTMLElement>);
      for (i = 0; i < slides.length; i++) {
        slides[i].style.display = "none";
      }
      slideIndex++;
      if (slideIndex > slides.length) {slideIndex = 1}
      slides[slideIndex-1].style.display = "block";
      setTimeout(showSlides, 5000); // Change image every 2 seconds
    }
  }}
  


