import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-header',
  template: `
    <nav class="navbar is-white">

      <!-- logo -->
      <div class="navbar-brand">
        <a class="navbar-item">
          <img src="assets/img/Clever-minds-academy-final.png" width=200px>
        </a>
      </div>

      <!-- menu -->
      <div class="navbar-menu">
        <div class="navbar-start">
          <a class="navbar-item" routerLink="">Home</a>
          <a class="navbar-item" routerLink="contact">Contact</a>
        
        </div>
      </div>
    </nav>
  `,
  styles: [`
  a.img {
 
    height: 340px;
    padding: 10px;
   }
  `]
})
export class HeaderComponent implements OnInit {
  constructor() {}
  ngOnInit() {}
}
